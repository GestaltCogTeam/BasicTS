from .arch import TimeKAN
from .config.timekan_config import TimeKANConfig

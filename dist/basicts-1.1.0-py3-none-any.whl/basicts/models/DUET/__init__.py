from .arch import DUET
from .config.duet_config import DUETConfig

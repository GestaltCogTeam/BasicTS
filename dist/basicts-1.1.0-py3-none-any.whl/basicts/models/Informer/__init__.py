from .arch import Informer
from .config.informer_config import InformerConfig

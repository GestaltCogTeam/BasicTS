from .arch import SOFTS
from .config.softs_config import SOFTSConfig
